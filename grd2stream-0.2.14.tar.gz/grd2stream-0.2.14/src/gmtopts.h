#ifndef GMTOPTS_H
#define GMTOPTS_H

/**
 * 
 */
int parse_R_option(char *item, double *w, double *e, double *s, double *n);


/**
 * 
 */
int parse_I_option (char *item, double *dlat, double *dlon);


#endif
